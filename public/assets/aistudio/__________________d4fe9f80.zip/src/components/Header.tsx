/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Menu, X, Construction, Phone, MessageCircle } from 'lucide-react';

interface HeaderProps {
  currentPage: 'home' | 'services' | 'products' | 'estimation';
  onNavigate: (page: 'home' | 'services' | 'products' | 'estimation', scrollToReviews?: boolean) => void;
}

export default function Header({ currentPage, onNavigate }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleNavClick = (page: 'home' | 'services' | 'products' | 'estimation', scrollToReviews = false) => {
    onNavigate(page, scrollToReviews);
    setIsOpen(false);
  };

  return (
    <header id="main-header" className="sticky top-0 z-50 bg-white border-b border-gray-150 h-[60px] flex items-center shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex justify-between items-center h-[60px]">
          {/* Logo / Brand */}
          <div 
            id="brand-logo" 
            className="flex items-center space-x-2.5 cursor-pointer shrink-0"
            onClick={() => handleNavClick('home')}
          >
            <img 
              src="https://i.postimg.cc/3R7Qz2kz/d-sin-th-y-ngmi-di-t-ngch-x-(12).png"
              alt="Sukhothai Sangapukan Logo" 
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full border border-red-500 object-cover shadow-sm shrink-0"
            />
            <div>
              <span className="text-xl font-bold tracking-tight text-red-600 block leading-tight font-sans">
                สุโขทัยแสงอุปกรณ์
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" className="hidden md:flex space-x-8 items-center">
            <button
              id="nav-home"
              onClick={() => handleNavClick('home')}
              className={`px-1 py-1 text-sm font-semibold transition-all ${
                currentPage === 'home' 
                  ? 'text-red-600 border-b-2 border-red-600 pb-1' 
                  : 'text-gray-500 hover:text-red-600'
              }`}
            >
              หน้าแรก
            </button>
            
            {/* Click "บริการและสินค้า" to navigate to products/services */}
            <button
              id="nav-services-products"
              onClick={() => handleNavClick('products')}
              className={`px-1 py-1 text-sm font-semibold transition-all ${
                (currentPage === 'products' || currentPage === 'services')
                  ? 'text-red-600 border-b-2 border-red-600 pb-1' 
                  : 'text-gray-500 hover:text-red-600'
              }`}
            >
              บริการและสินค้า
            </button>

            <button
              id="nav-reviews"
              onClick={() => handleNavClick('home', true)}
              className="px-1 py-1 text-sm font-semibold text-gray-500 hover:text-red-600 transition-colors"
            >
              งานรีวิว
            </button>
          </nav>

          {/* Slogan Desktop */}
          <div className="hidden lg:block text-right">
            <span className="text-sm font-light text-gray-500 italic bg-gray-50 px-3 py-1.5 rounded-full border border-gray-100">
              “เริ่มที่นี่ no worry เรื่องบ้าน”
            </span>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              id="mobile-menu-btn"
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-500 hover:text-red-600 hover:bg-gray-50 focus:outline-none"
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div id="mobile-nav" className="md:hidden bg-white border-t border-gray-100 py-3 px-4 space-y-2 shadow-inner">
          <button
            id="mob-nav-home"
            onClick={() => handleNavClick('home')}
            className={`block w-full text-left px-4 py-2.5 rounded-lg text-base font-medium ${
              currentPage === 'home' ? 'bg-red-50 text-red-600' : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            หน้าแรก
          </button>
          <button
            id="mob-nav-products"
            onClick={() => handleNavClick('products')}
            className={`block w-full text-left px-4 py-2.5 rounded-lg text-base font-medium ${
              currentPage === 'products' ? 'bg-red-50 text-red-600' : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            สินค้าและคลังอุปกรณ์
          </button>
          <button
            id="mob-nav-services"
            onClick={() => handleNavClick('services')}
            className={`block w-full text-left px-4 py-2.5 rounded-lg text-base font-medium ${
              currentPage === 'services' ? 'bg-red-50 text-red-600' : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            บริการช่างมืออาชีพ
          </button>
          <button
            id="mob-nav-estimation"
            onClick={() => handleNavClick('estimation')}
            className={`block w-full text-left px-4 py-2.5 rounded-lg text-base font-medium ${
              currentPage === 'estimation' ? 'bg-red-50 text-red-600' : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            ถอดแบบประมาณการ
          </button>
          <button
            id="mob-nav-reviews"
            onClick={() => handleNavClick('home', true)}
            className="block w-full text-left px-4 py-2.5 rounded-lg text-base font-medium text-gray-600 hover:bg-gray-50"
          >
            งานรีวิว
          </button>
        </div>
      )}
    </header>
  );
}
