/**
 * GOOGLE APPS SCRIPT - สุโขทัยแสงอุปกรณ์ (ถอดแบบประมาณการ)
 * 
 * วิธีการติดตั้งและใช้งานสำหรับเจ้าของร้าน:
 * 1. เปิดไฟล์ Google Sheets ของคุณ (ID: 1FVCddjaT5h3OY2CLfmQ93brzs20tKiczPn8R0DGad4Y)
 * 2. ไปที่เมนู "ส่วนขยาย" (Extensions) > "Apps Script"
 * 3. ลบโค้ดเดิมในนั้นออกทั้งหมด แล้วคัดลอก (Copy) โค้ดทั้งหมดในไฟล์นี้ไปวางแทน
 * 4. หากต้องการบันทึกไฟล์แนบ (รูปภาพหรือ PDF) ไปยังโฟลเดอร์ Google Drive เฉพาะ:
 *    - ให้สร้างโฟลเดอร์ใน Google Drive ของคุณแล้วคัดลอก ID ของโฟลเดอร์มาใส่ในช่อง FOLDER_ID ด้านล่าง (ถ้าไม่ใส่จะบันทึกไว้ที่ Root Drive)
 * 5. กดปุ่มบันทึก (ไอคอนแผ่นดิสก์)
 * 6. กดปุ่ม "การทำให้ใช้งานได้" (Deploy) > "การจัดการการทำให้ใช้งานได้ใหม่" (New deployment)
 * 7. เลือกประเภทเป็น "เว็บแอป" (Web app)
 * 8. ตั้งค่าดังนี้:
 *    - อัปเดตคำอธิบาย: เช่น "ถอดแบบประมาณการระบบใหม่"
 *    - เรียกใช้ในฐานะ (Execute as): "ฉัน" (Your email)
 *    - ผู้มีสิทธิ์เข้าถึง (Who has access): "ทุกคน" (Anyone) **สำคัญมากเพื่อให้ผู้ใช้ทั่วไปส่งข้อมูลได้**
 * 9. กดปุ่ม "ทำให้ใช้งานได้" (Deploy)
 * 10. หากมีป๊อปอัพขอสิทธิ์ ให้กด "ให้สิทธิ์เข้าถึง" (Authorize access) และยืนยันสิทธิ์ให้เรียบร้อย
 * 11. คัดลอก "URL ของเว็บแอป" ที่ได้ (เช่น https://script.google.com/macros/s/.../exec)
 * 12. นำ URL ที่ได้มาใส่ในไฟล์ `.env` บน Netlify ในตัวแปรชื่อ `VITE_APPS_SCRIPT_URL` เพื่อเชื่อมต่อให้สมบูรณ์!
 */

// ใส่ ID ของโฟลเดอร์ Google Drive ที่ต้องการเก็บไฟล์แนบ (เว้นว่างไว้หากต้องการเก็บในไดรฟ์หลัก)
const DRIVE_FOLDER_ID = ""; 

function doPost(e) {
  try {
    // กำหนด CORS Headers เพื่อให้ React เรียกใช้งานข้ามโดเมนได้สะดวก
    const headers = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };
    
    // ตรวจสอบ Parameter ของ request
    let postData;
    if (e.postData && e.postData.contents) {
      postData = JSON.parse(e.postData.contents);
    } else {
      postData = e.parameter;
    }
    
    const spreadsheetId = "1FVCddjaT5h3OY2CLfmQ93brzs20tKiczPn8R0DGad4Y";
    const sheetName = "ถอดแบบประมาณการ";
    
    const ss = SpreadsheetApp.openById(spreadsheetId);
    let sheet = ss.getSheetByName(sheetName);
    
    // หากไม่มีแท็บ "ถอดแบบประมาณการ" ให้สร้างใหม่พร้อมใส่หัวคอลัมน์
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
      sheet.appendRow([
        "ชื่อผู้ติดต่อ", 
        "เบอร์โทรศัพท์", 
        "ช่องทางการติดต่อออนไลน์", 
        "ที่อยู่อาคาร", 
        "แบบที่ต้องการแปลนอาหาร หรือใส่ลิงก์ไดรฟ์",
        "วันที่ส่งข้อมูล"
      ]);
      // ปรับแต่งความสวยงามของหัวข้อตารางเล็กน้อย
      sheet.getRange(1, 1, 1, 6).setFontWeight("bold").setBackground("#1A1A1E").setFontColor("#FFFFFF");
    }
    
    // จัดการข้อมูลไฟล์แนบ (ถ้าส่งมาเป็น Base64)
    let fileUrl = "";
    if (postData.fileData && postData.fileName) {
      try {
        const fileBytes = Utilities.base64Decode(postData.fileData.split(",")[1] || postData.fileData);
        const blob = Utilities.newBlob(fileBytes, postData.fileType || "application/octet-stream", postData.fileName);
        
        let folder;
        if (DRIVE_FOLDER_ID && DRIVE_FOLDER_ID.trim() !== "") {
          folder = DriveApp.getFolderById(DRIVE_FOLDER_ID);
        } else {
          folder = DriveApp.getRootFolder();
        }
        
        const file = folder.createFile(blob);
        file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
        fileUrl = file.getUrl();
      } catch (fileError) {
        fileUrl = "เกิดข้อผิดพลาดในการเซฟไฟล์แนบ: " + fileError.toString();
      }
    }
    
    // เลือกใช้ลิงก์ที่ให้มา หรือใช้ลิงก์ไฟล์ที่อัปโหลดขึ้นไดรฟ์
    const finalFileOrLink = fileUrl || postData.driveLink || "ไม่มีไฟล์แนบ";
    
    // เพิ่มข้อมูลลงใน Sheet แถวใหม่ล่าสุด เรียงคอลัมน์ A ถึง E (และ F เป็นวันที่)
    sheet.appendRow([
      postData.name || "",
      postData.phone || "",
      postData.onlineContact || "",
      postData.address || "",
      finalFileOrLink,
      new Date().toLocaleString("th-TH")
    ]);
    
    const response = { status: "success", fileUrl: fileUrl, message: "บันทึกข้อมูลเรียบร้อยแล้ว" };
    return ContentService.createTextOutput(JSON.stringify(response))
                         .setMimeType(ContentService.MimeType.JSON);
                         
  } catch (error) {
    const errorResponse = { status: "error", message: error.toString() };
    return ContentService.createTextOutput(JSON.stringify(errorResponse))
                         .setMimeType(ContentService.MimeType.JSON);
  }
}

// รองรับการตรวจสอบ OPTIONS เพื่อหลีกเลี่ยงข้อผิดพลาด Preflight CORS ในเบราว์เซอร์
function doOptions(e) {
  const output = ContentService.createTextOutput();
  return output.setMimeType(ContentService.MimeType.TEXT);
}
