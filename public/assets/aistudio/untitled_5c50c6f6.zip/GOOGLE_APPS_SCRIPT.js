/**
 * GOOGLE APPS SCRIPT - สุโขทัยแสงอุปกรณ์
 * 
 * เชื่อมต่อกับ Google Sheet ID: 1wcGVcCeBj1EA6WTpkTKEuy_1n-Mjm1qwhSlz0iS_zG4
 * 
 * ระบบรองรับ:
 * 1. รับคำสั่งซื้อสินค้าจากเว็บไซต์ บันทึกลง Google Sheet ทันที (รองรับทั้ง จัดส่งตามที่อยู่ และ รับเองที่ร้าน)
 * 2. รองรับข้อมูลใบกำกับภาษี, พิกัด GPS และรูปสลิปโอนเงิน
 * 3. ส่งอีเมลแจ้งเตือนคำสั่งซื้ออัตโนมัติไปยัง scghomessk@gmail.com
 * 4. ฟังก์ชัน testInsertOrder() สำหรับกดทดสอบบันทึกข้อมูลเข้า Sheet ได้ใน 1 วินาที
 * 
 * -------------------------------------------------------------
 * วิธีการติดตั้งและอัปเดต:
 * 1. นำโค้ดทั้งหมดในไฟล์นี้ไปวางใน Google Apps Script (ไฟล์ Code.gs)
 * 2. กดปุ่มบันทึก (Ctrl+S หรือรูปแผ่นดิสก์)
 * 3. กด "การทำให้ใช้งานได้" (Deploy) > "การจัดการการทำให้ใช้งานได้ใหม่" (Manage deployments)
 * 4. กดไอคอนดินสอแก้ไข (Edit) > เลือกเวอร์ชัน: "เวอร์ชันใหม่" (New version)
 *    - ตรวจสอบว่า "ผู้มีสิทธิ์เข้าถึง" (Who has access) เป็น "ทุกคน" (Anyone)
 * 5. กดปุ่ม "ทำให้ใช้งานได้" (Deploy)
 * -------------------------------------------------------------
 */

// อีเมลของร้านสำหรับรับการแจ้งเตือนคำสั่งซื้อ
const TARGET_STORE_EMAIL = "scghomessk@gmail.com";

// ID ของ Google Sheet ตามที่ระบุเจาะจง
const SPREADSHEET_ID = "1wcGVcCeBj1EA6WTpkTKEuy_1n-Mjm1qwhSlz0iS_zG4";

// ใส่ ID โฟลเดอร์ Google Drive หากต้องการเก็บไฟล์แนบสลิปหรือแบบแปลน (เว้นว่างไว้หากเก็บในไดรฟ์หลัก)
const DRIVE_FOLDER_ID = "";

/**
 * ค้นหาหรือเปิด Google Spreadsheet ID: 1wcGVcCeBj1EA6WTpkTKEuy_1n-Mjm1qwhSlz0iS_zG4
 * บังคับเปิดชีตคำสั่งซื้อตาม ID โดยตรง ไม่บันทึกลงชีตสินค้า
 */
function getTargetSpreadsheet() {
  if (SPREADSHEET_ID && SPREADSHEET_ID.trim() !== "") {
    try {
      const ss = SpreadsheetApp.openById(SPREADSHEET_ID.trim());
      if (ss) return ss;
    } catch (err) {
      Logger.log("❌ ไม่สามารถเปิด Sheet ID: " + SPREADSHEET_ID + " ข้อผิดพลาด: " + err.toString());
      throw new Error("ไม่สามารถเปิด Google Sheet ID: " + SPREADSHEET_ID + " ได้ (" + err.toString() + ") กรุณาตรวจสอบสิทธิ์การแชร์ชีต หรือเปิด Apps Script จากชีตใหม่โดยตรง");
    }
  }

  // หากไม่ได้ระบุ SPREADSHEET_ID ให้ใช้ชีตปัจจุบัน
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) return active;

  throw new Error("ไม่พบ Google Sheet ID: " + SPREADSHEET_ID);
}

/**
 * ค้นหาหรือสร้างแท็บ "รายการคำสั่งซื้อ" พร้อมกำหนดหัวตาราง 24 คอลัมน์
 */
function getOrCreateOrderSheet(ss) {
  const sheetName = "รายการคำสั่งซื้อ";
  let sheet = ss.getSheetByName(sheetName);

  const headers = [
    "รหัสออเดอร์",
    "วันที่-เวลาสั่งซื้อ",
    "ชื่อลูกค้า",
    "เบอร์โทรศัพท์",
    "LINE ID",
    "อีเมลลูกค้า",
    "รูปแบบการจัดส่ง",
    "ที่อยู่จัดส่ง / สาขาที่รับ",
    "พิกัด GPS",
    "ลิงก์หมุด Google Maps",
    "ระยะทาง (กม.)",
    "โซนจัดส่ง",
    "ยอดรวมสินค้า (บาท)",
    "ค่าจัดส่ง (บาท)",
    "ยอดสุทธิทั้งสิ้น (บาท)",
    "วิธีชำระเงิน",
    "สลิปโอนเงิน",
    "ขอใบกำกับภาษี",
    "ประเภทผู้เสียภาษี",
    "ชื่อผู้เสียภาษี/นิติบุคคล",
    "เลขประจำตัวผู้เสียภาษี",
    "สาขา",
    "ที่อยู่ออกใบกำกับภาษี",
    "รายการสินค้าทั้งหมด",
    "หมายเหตุเพิ่มเติม",
    "สถานะคำสั่งซื้อ"
  ];

  if (!sheet) {
    try {
      sheet = ss.insertSheet(sheetName);
    } catch (e) {
      sheet = ss.getActiveSheet();
      sheet.setName(sheetName);
    }

    sheet.appendRow(headers);
    sheet.getRange(1, 1, 1, headers.length)
      .setFontWeight("bold")
      .setBackground("#DC2626")
      .setFontColor("#FFFFFF")
      .setHorizontalAlignment("center");
    sheet.setFrozenRows(1);

    for (let c = 1; c <= headers.length; c++) {
      try {
        sheet.autoResizeColumn(c);
      } catch (colErr) {}
    }
  } else {
    // หากแท็บมีอยู่แล้ว ตรวจสอบว่ามีคอลัมน์ "อีเมลลูกค้า" หรือไม่ ถ้ายังไม่มีให้แทรกอัตโนมัติ
    try {
      const lastCol = sheet.getLastColumn();
      if (lastCol > 0) {
        const currentHeaders = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
        const hasEmailCol = currentHeaders.some(function(h) {
          return h && h.toString().indexOf("อีเมล") >= 0;
        });
        if (!hasEmailCol && lastCol >= 5) {
          sheet.insertColumnAfter(5);
          sheet.getRange(1, 6).setValue("อีเมลลูกค้า")
            .setFontWeight("bold")
            .setBackground("#DC2626")
            .setFontColor("#FFFFFF")
            .setHorizontalAlignment("center");
        }
      }
    } catch (migErr) {
      Logger.log("Migration check notice: " + migErr.toString());
    }
  }

  return sheet;
}

/**
 * ฟังก์ชันสำหรับทดสอบบันทึกข้อมูลคำสั่งซื้อเข้า Sheet 1wcGVcCeBj1EA6WTpkTKEuy_1n-Mjm1qwhSlz0iS_zG4
 * คุณสามารถกดเลือกฟังก์ชันนี้ใน Apps Script แล้วกดปุ่ม "เรียกใช้" (Run) เพื่อเช็คได้ทันที
 */
function testInsertOrder() {
  const ss = getTargetSpreadsheet();
  const sheet = getOrCreateOrderSheet(ss);

  const testOrderId = "TEST-" + Math.floor(1000 + Math.random() * 9000);
  const nowStr = new Date().toLocaleString("th-TH");

  sheet.appendRow([
    testOrderId,
    nowStr,
    "ทดสอบระบบ (สุโขทัยแสงอุปกรณ์)",
    "055-616437",
    "@exu1868n",
    "scghomessk@gmail.com",
    "จัดส่งตามที่อยู่",
    "123 ต.ธานี อ.เมือง จ.สุโขทัย",
    "17.0076, 99.8234",
    "https://maps.google.com?q=17.0076,99.8234",
    "2.5",
    "ในเขตเทศบาลตำบลธานี",
    "5000",
    "0",
    "5000",
    "โอนเงินผ่านธนาคาร กสิกรไทย 157-2-45402-5",
    "ทดสอบสลิป",
    "ไม่ต้องการ",
    "-",
    "-",
    "-",
    "-",
    "-",
    "1. ปูนซีเมนต์ SCG แดง x 10 ถุง = 1,490 บาท",
    "ทดสอบการเชื่อมต่อระบบเข้า Sheet ID 1wcGVcCeBj1EA6WTpkTKEuy_1n-Mjm1qwhSlz0iS_zG4",
    "ทดสอบสำเร็จ"
  ]);

  SpreadsheetApp.flush();
  Logger.log("✅ ทดสอบบันทึกข้อมูลเข้า Sheet ID: " + SPREADSHEET_ID + " สำเร็จแล้ว!");
  Logger.log("สามารถเปิดดูแถวใหม่ใน Sheet ได้ทันที: " + ss.getUrl());
}

/**
 * ฟังก์ชันสำหรับทดสอบส่งอีเมลคำสั่งซื้อไปยังทั้งร้าน (scghomessk@gmail.com) และอีเมลลูกค้า
 * สามารถกดเลือกฟังก์ชันนี้ใน Apps Script แล้วกดปุ่ม "เรียกใช้" (Run) เพื่อเช็คอีเมลเข้าได้ทันที
 */
function testSendOrderEmail() {
  const testCustomerEmail = "dungdaww978@gmail.com"; // อีเมลสำหรับทดสอบรับคำสั่งซื้อฝั่งลูกค้า
  const orderId = "TEST-EMAIL-" + Math.floor(1000 + Math.random() * 9000);

  const htmlBody = 
    "<div style='font-family:Prompt, Tahoma, sans-serif; max-width:650px; margin:0 auto; padding:20px; border:1px solid #e5e7eb; border-radius:12px; background:#ffffff;'>" +
      "<div style='background:#DC2626; color:#ffffff; padding:16px 20px; border-radius:8px; text-align:center; margin-bottom:20px;'>" +
        "<h2 style='margin:0 0 4px 0; font-size:22px; font-weight:bold;'>สุโขทัยแสงอุปกรณ์</h2>" +
        "<p style='margin:0; font-size:13px; opacity:0.95;'>ทดสอบส่งอีเมลคำสั่งซื้ออัตโนมัติ</p>" +
      "</div>" +
      "<div style='background:#f9fafb; padding:16px; border-radius:8px; margin-bottom:16px; border:1px solid #f3f4f6;'>" +
        "<p style='margin:4px 0; font-size:14px;'><strong>รหัสคำสั่งซื้อ:</strong> <span style='color:#DC2626; font-weight:bold;'>#" + orderId + "</span></p>" +
        "<p style='margin:4px 0; font-size:13px;'><strong>วันที่:</strong> " + new Date().toLocaleString("th-TH") + "</p>" +
        "<p style='margin:4px 0; font-size:13px;'><strong>ชื่อผู้สั่งซื้อ:</strong> ทดสอบระบบอีเมล</p>" +
        "<p style='margin:4px 0; font-size:13px;'><strong>เบอร์โทรศัพท์:</strong> 055-616437</p>" +
        "<p style='margin:4px 0; font-size:13px;'><strong>อีเมลลูกค้า:</strong> " + testCustomerEmail + "</p>" +
        "<div style='background:#fef3c7; border:1px solid #fcd34d; border-radius:8px; padding:10px 14px; margin-top:10px; font-size:13px; color:#92400e; font-weight:bold;'>" +
          "🕒 <strong>รอพนักงานติดต่อกลับเพื่อนัดวันจัดส่งสินค้า</strong>" +
        "</div>" +
      "</div>" +
      "<div style='text-align:center; color:#6b7280; font-size:11px; padding-top:16px; border-top:1px solid #f3f4f6;'>" +
        "ร้านสุโขทัยแสงอุปกรณ์ | เริ่มที่นี่ no worry เรื่องบ้าน • โทร: 055-616437 | LINE: @exu1868n" +
      "</div>" +
    "</div>";

  // 1. ส่งถึงร้านและ CC ถึงลูกค้า
  MailApp.sendEmail({
    to: TARGET_STORE_EMAIL,
    name: "ร้านสุโขทัยแสงอุปกรณ์ (SCG Home สุโขทัย)",
    cc: testCustomerEmail,
    replyTo: testCustomerEmail,
    subject: "📦 [ทดสอบส่งเมล] คำสั่งซื้อ #" + orderId + " - ร้านสุโขทัยแสงอุปกรณ์",
    htmlBody: htmlBody
  });

  // 2. ส่งตรงถึงลูกค้าอีกฉบับ
  MailApp.sendEmail({
    to: testCustomerEmail,
    name: "ร้านสุโขทัยแสงอุปกรณ์",
    replyTo: TARGET_STORE_EMAIL,
    subject: "📦 ยืนยันคำสั่งซื้อ #" + orderId + " - ร้านสุโขทัยแสงอุปกรณ์",
    htmlBody: 
      "<div style='font-family:Prompt, Tahoma, sans-serif; max-width:650px; margin:0 auto 12px auto; padding:14px; border-radius:10px; background:#f0fdf4; border:1px solid #bbf7d0; text-align:center;'>" +
        "<h3 style='margin:0 0 4px 0; color:#166534; font-size:16px;'>ขอบพระคุณสำหรับคำสั่งซื้อค่ะ! (อีเมลทดสอบ)</h3>" +
        "<p style='margin:0; font-size:13px; color:#15803d;'>ทางร้านสุโขทัยแสงอุปกรณ์ได้รับคำสั่งซื้อของคุณเรียบร้อยแล้ว ด้านล่างคือใบสรุปรายการสั่งซื้อของคุณค่ะ</p>" +
      "</div>" + htmlBody
  });

  Logger.log("✅ ทดสอบส่งอีเมลไปยังร้าน " + TARGET_STORE_EMAIL + " และลูกค้า " + testCustomerEmail + " เรียบร้อยแล้ว!");
}

/**
 * รับคำขอ GET สำหรับตรวจสอบสถานะเว็บแอปผ่านเบราว์เซอร์
 */
function doGet(e) {
  try {
    const ss = getTargetSpreadsheet();
    return ContentService.createTextOutput(
      JSON.stringify({
        status: "success",
        message: "ระบบเว็บแอป สุโขทัยแสงอุปกรณ์ ทำงานปกติ",
        sheetId: SPREADSHEET_ID,
        sheetUrl: ss.getUrl()
      })
    ).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(
      JSON.stringify({
        status: "error",
        message: err.toString(),
        sheetId: SPREADSHEET_ID
      })
    ).setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * รับคำขอ POST คำสั่งซื้อจากหน้าเว็บไซต์
 */
function doPost(e) {
  try {
    let postData = {};

    // อ่านข้อมูล request รองรับทั้ง JSON, Text, Parameter
    if (e && e.postData && e.postData.contents) {
      try {
        postData = JSON.parse(e.postData.contents);
      } catch (jsonErr) {
        try {
          postData = JSON.parse(decodeURIComponent(e.postData.contents));
        } catch (e2) {
          postData = e.parameter || {};
        }
      }
    } else if (e && e.parameter) {
      postData = e.parameter;
    }

    const ss = getTargetSpreadsheet();

    // ==========================================
    // 1. กรณี: คำสั่งซื้อสินค้า (Order) จากหน้าเว็บ
    // ==========================================
    if (postData.action === "create_order" || postData.orderId) {
      const sheet = getOrCreateOrderSheet(ss);

      // บันทึกไฟล์รูปสลิปโอนเงิน (ถ้ามีแนบมา)
      let slipUrl = "";
      let slipBlob = null;
      if (postData.slipData && postData.slipData.trim() !== "") {
        try {
          const rawBase64 = postData.slipData.split(",")[1] || postData.slipData;
          const fileBytes = Utilities.base64Decode(rawBase64);
          const mimeType = postData.slipType || "image/jpeg";
          const fileName = "Slip-" + (postData.orderId || Date.now()) + (postData.slipName ? ("-" + postData.slipName) : ".jpg");
          slipBlob = Utilities.newBlob(fileBytes, mimeType, fileName);

          let folder;
          if (DRIVE_FOLDER_ID && DRIVE_FOLDER_ID.trim() !== "") {
            folder = DriveApp.getFolderById(DRIVE_FOLDER_ID);
          } else {
            folder = DriveApp.getRootFolder();
          }

          const slipFile = folder.createFile(slipBlob);
          slipFile.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
          slipUrl = slipFile.getUrl();
        } catch (slipErr) {
          slipUrl = "แนบสลิปแล้ว (Drive: " + slipErr.toString() + ")";
        }
      }

      // แปลงรายการสินค้าเป็นข้อความสรุป
      let itemsSummary = "";
      if (Array.isArray(postData.items)) {
        itemsSummary = postData.items.map(function(it, idx) {
          const barcodeText = it.barcode ? " [บาร์: " + it.barcode + "]" : "";
          return (idx + 1) + ". " + it.name + barcodeText + " x " + it.quantity + " " + (it.unit || "ชิ้น") + " = " + Number(it.itemTotal || 0).toLocaleString() + " บาท";
        }).join("\n");
      }

      const isPickup = postData.deliveryMethod === "pickup" || postData.deliveryMethod === "store_pickup";
      const deliveryMethodLabel = isPickup ? "รับสินค้าเองที่หน้าร้าน" : "จัดส่งตามที่อยู่";

      const mapsPinUrl = (postData.lat && postData.lng && !isPickup)
        ? "https://www.google.com/maps?q=" + postData.lat + "," + postData.lng
        : (isPickup ? "https://maps.app.goo.gl/wNSma6LbqY2ebmmf6" : "-");

      const orderDateStr = new Date().toLocaleString("th-TH");

      // บันทึกลง Sheet: 1wcGVcCeBj1EA6WTpkTKEuy_1n-Mjm1qwhSlz0iS_zG4
      let sheetSaveStatus = "success";
      try {
        sheet.appendRow([
          postData.orderId || "",
          orderDateStr,
          postData.customerName || "",
          postData.phone || "",
          postData.lineId || "",
          postData.customerEmail || "-",
          deliveryMethodLabel,
          isPickup ? "รับเองที่ร้านสุโขทัยแสงอุปกรณ์" : (postData.addressDetail || ""),
          isPickup ? "หน้าร้านสุโขทัยแสงอุปกรณ์" : ((postData.lat || 0) + ", " + (postData.lng || 0)),
          mapsPinUrl,
          isPickup ? 0 : (postData.distanceKm || 0),
          isPickup ? "รับเองที่ร้าน (ฟรี)" : (postData.zoneName || ""),
          postData.subtotal || 0,
          postData.deliveryFee || 0,
          postData.grandTotal || 0,
          postData.paymentMethod || "",
          (slipUrl && slipUrl.indexOf("http") === 0)
            ? ('=HYPERLINK("' + slipUrl + '", "📄 เปิดดูรูปสลิป")')
            : (slipUrl || (postData.slipData ? "แนบรูปสลิปในออเดอร์แล้ว" : (postData.paymentMethod && postData.paymentMethod.indexOf("โอน") >= 0 ? "⚠️ ยังไม่แนบสลิป" : "ไม่มีสลิป"))),
          postData.needTaxInvoice ? "ต้องการ" : "ไม่ต้องการ",
          postData.taxType || "-",
          postData.taxName || "-",
          postData.taxId || "-",
          postData.taxBranch || "-",
          postData.taxAddress || "-",
          itemsSummary,
          postData.notes || "",
          isPickup ? "ลูกค้ารับเองที่ร้าน (รอนัดหมาย)" : "รอยืนยันการจัดส่ง"
        ]);
        SpreadsheetApp.flush();
      } catch (sheetErr) {
        Logger.log("Sheet append error: " + sheetErr.toString());
        sheetSaveStatus = "error: " + sheetErr.toString();
      }

      // ส่งอีเมลแจ้งเตือนอัตโนมัติไปยัง TARGET_STORE_EMAIL
      let emailSendStatus = "not_sent";
      try {
        const pickupSubjectTag = isPickup ? " [รับเองที่ร้าน]" : " [จัดส่ง]";
        const emailSubject = "📦 คำสั่งซื้อใหม่ #" + postData.orderId + pickupSubjectTag + " คุณ" + (postData.customerName || "ลูกค้า") + " [ยอด ฿" + Number(postData.grandTotal || 0).toLocaleString() + "]";

        // บล็อกสลิปโอนเงิน (หากแนบมา จะแสดงรูปและลิงก์ / หากเลือกโอนแต่ยังไม่แนบ จะแสดงกล่องเตือนสีแดง)
        let slipBlockHtml = "";
        let slipBlockPlain = "";
        if (postData.slipData) {
          const imgSrc = slipBlob ? "cid:slipImg" : postData.slipData;
          slipBlockHtml = 
            "<div style='background:#f0fdf4; border:2px solid #86efac; border-radius:10px; padding:16px; margin-bottom:16px;'>" +
              "<h4 style='margin:0 0 10px 0; color:#166534; font-size:15px; font-weight:bold;'>📄 รูปภาพสลิปโอนเงิน (หลักฐานการชำระเงิน):</h4>" +
              "<div style='text-align:center; margin:12px 0; background:#ffffff; padding:10px; border-radius:8px; border:1px solid #dcfce7; display:inline-block; max-width:100%;'>" +
                "<img src='" + imgSrc + "' style='max-width:340px; max-height:480px; width:100%; height:auto; border-radius:6px; box-shadow:0 2px 8px rgba(0,0,0,0.1);' alt='สลิปการโอนเงิน' />" +
              "</div>" +
              (slipUrl && slipUrl.indexOf("http") === 0 ? "<p style='margin:10px 0 0 0; font-size:13px; text-align:center;'><a href='" + slipUrl + "' target='_blank' style='background:#16a34a; color:#ffffff; padding:8px 16px; border-radius:6px; font-weight:bold; text-decoration:none; display:inline-block;'>🔗 คลิกเปิดดูรูปสลิปขนาดเต็มบน Google Drive ↗</a></p>" : "") +
            "</div>";
          slipBlockPlain = "\n📄 หลักฐานการโอนเงิน (สลิป): " + (slipUrl ? slipUrl : "แนบรูปสลิปในออเดอร์แล้ว") + "\n";
        } else if (postData.paymentMethod && postData.paymentMethod.indexOf("โอน") >= 0) {
          // แจ้งเตือนกรณีเลือกโอนเงินแต่ไม่ได้แนบสลิปมา
          slipBlockHtml = 
            "<div style='background:#fff1f2; border:2px dashed #f43f5e; border-radius:10px; padding:14px; margin-bottom:16px;'>" +
              "<h4 style='margin:0 0 6px 0; color:#be123c; font-size:14px; font-weight:bold;'>⚠️ สถานะสลิป: ลูกค้ายังไม่ได้แนบสลิปโอนเงินในระบบ</h4>" +
              "<p style='margin:0; font-size:13px; color:#881337; line-height:1.5;'>" +
                "ลูกค้าเลือกชำระเงินโดยการโอนเงิน แต่ยังไม่ได้แนบสลิปตอนสั่งซื้อ<br/>" +
                "👉 กรุณาโทรติดต่อลูกค้าที่เบอร์: <a href='tel:" + postData.phone + "' style='color:#be123c; font-weight:bold; text-decoration:underline; font-size:14px;'>" + postData.phone + "</a> หรือรอรับสลิปผ่านทาง LINE @exu1868n ก่อนจัดส่งสินค้า" +
              "</p>" +
            "</div>";
          slipBlockPlain = "\n⚠️ สถานะสลิป: ลูกค้ายังไม่ได้แนบสลิป (กรุณาโทรตรวจสอบยอดเงิน)\n";
        }

        // บล็อกข้อมูลใบกำกับภาษี
        let taxBlockHtml = "";
        let taxBlockPlain = "";
        if (postData.needTaxInvoice) {
          taxBlockHtml = 
            "<div style='background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:12px; margin-bottom:16px;'>" +
              "<h4 style='margin:0 0 8px 0; color:#1e40af; font-size:14px;'>🧾 ข้อมูลสำหรับออกใบกำกับภาษี:</h4>" +
              "<p style='margin:3px 0; font-size:13px;'><strong>ประเภท:</strong> " + (postData.taxType || "-") + "</p>" +
              "<p style='margin:3px 0; font-size:13px;'><strong>ชื่อผู้เสียภาษี:</strong> " + (postData.taxName || "-") + "</p>" +
              "<p style='margin:3px 0; font-size:13px;'><strong>เลขประจำตัวผู้เสียภาษี:</strong> " + (postData.taxId || "-") + "</p>" +
              "<p style='margin:3px 0; font-size:13px;'><strong>สาขา:</strong> " + (postData.taxBranch || "-") + "</p>" +
              "<p style='margin:3px 0; font-size:13px;'><strong>ที่อยู่ออกใบกำกับ:</strong> " + (postData.taxAddress || "-") + "</p>" +
            "</div>";
          taxBlockPlain = "\n🧾 ข้อมูลใบกำกับภาษี:\n- ชื่อ: " + (postData.taxName || "-") + "\n- เลขผู้เสียภาษี: " + (postData.taxId || "-") + "\n- สาขา: " + (postData.taxBranch || "-") + "\n- ที่อยู่: " + (postData.taxAddress || "-") + "\n";
        }

        const deliveryNoticeHtml = isPickup
          ? "<div style='background:#dcfce7; border:1px solid #86efac; border-radius:8px; padding:10px 14px; margin-top:10px; font-size:13px; color:#166534; font-weight:bold;'>" +
              "🏬 <strong>ลูกค้าระบุ: รับสินค้าเองที่ร้าน (สุโขทัยแสงอุปกรณ์)</strong><br/>" +
              "<span style='font-size:12px; font-weight:normal;'>ทางร้านจะเช็คสต็อกสินค้าและโทรนัดหมายวันรับสินค้ากับลูกค้าผ่านเบอร์: <a href='tel:" + postData.phone + "' style='color:#15803d; font-weight:bold;'>" + postData.phone + "</a></span>" +
            "</div>"
          : "<div style='background:#fef3c7; border:1px solid #fcd34d; border-radius:8px; padding:10px 14px; margin-top:10px; font-size:13px; color:#92400e; font-weight:bold;'>" +
              "🕒 <strong>รอพนักงานติดต่อกลับเพื่อนัดวันจัดส่งสินค้า</strong>" +
            "</div>";

        const itemsTableHtml = 
          "<h3 style='margin:16px 0 8px 0; color:#111827; font-size:15px; font-weight:bold;'>🛒 รายการสินค้าในออเดอร์</h3>" +
          "<table style='width:100%; border-collapse:collapse; margin-bottom:20px; font-size:13px;'>" +
            "<thead>" +
              "<tr style='background:#f3f4f6; text-align:left;'>" +
                "<th style='padding:8px 10px; border-bottom:2px solid #e5e7eb;'>รายการ</th>" +
                "<th style='padding:8px 10px; border-bottom:2px solid #e5e7eb; text-align:center;'>จำนวน</th>" +
                "<th style='padding:8px 10px; border-bottom:2px solid #e5e7eb; text-align:right;'>ราคา/หน่วย</th>" +
                "<th style='padding:8px 10px; border-bottom:2px solid #e5e7eb; text-align:right;'>รวม (บาท)</th>" +
              "</tr>" +
            "</thead>" +
            "<tbody>" +
              (Array.isArray(postData.items) ? postData.items.map(function(it) {
                return "<tr>" +
                  "<td style='padding:8px 10px; border-bottom:1px solid #f3f4f6;'>" + it.name + (it.barcode ? " <span style='color:#6b7280; font-size:11px;'>(" + it.barcode + ")</span>" : "") + "</td>" +
                  "<td style='padding:8px 10px; border-bottom:1px solid #f3f4f6; text-align:center;'>" + it.quantity + " " + (it.unit || "ชิ้น") + "</td>" +
                  "<td style='padding:8px 10px; border-bottom:1px solid #f3f4f6; text-align:right;'>฿" + Number(it.unitPrice || 0).toLocaleString() + "</td>" +
                  "<td style='padding:8px 10px; border-bottom:1px solid #f3f4f6; text-align:right; font-weight:bold;'>฿" + Number(it.itemTotal || 0).toLocaleString() + "</td>" +
                "</tr>";
              }).join("") : "") +
            "</tbody>" +
            "<tfoot>" +
              "<tr>" +
                "<td colspan='3' style='padding:8px 10px; text-align:right; color:#4b5563;'>ยอดรวมค่าสินค้า:</td>" +
                "<td style='padding:8px 10px; text-align:right; font-weight:bold;'>฿" + Number(postData.subtotal || 0).toLocaleString() + "</td>" +
              "</tr>" +
              "<tr>" +
                "<td colspan='3' style='padding:8px 10px; text-align:right; color:#4b5563;'>ค่าจัดส่ง:</td>" +
                "<td style='padding:8px 10px; text-align:right; font-weight:bold; color:#DC2626;'>" + (Number(postData.deliveryFee || 0) === 0 ? "ฟรี (฿0)" : "฿" + Number(postData.deliveryFee || 0).toLocaleString()) + "</td>" +
              "</tr>" +
              "<tr style='background:#fef2f2;'>" +
                "<td colspan='3' style='padding:10px; text-align:right; font-size:15px; font-weight:bold; color:#991B1B;'>ยอดสุทธิทั้งสิ้น:</td>" +
                "<td style='padding:10px; text-align:right; font-size:18px; font-weight:bold; color:#DC2626;'>฿" + Number(postData.grandTotal || 0).toLocaleString() + "</td>" +
              "</tr>" +
            "</tfoot>" +
          "</table>";

        const storeFooterHtml = 
          "<div style='text-align:center; color:#6b7280; font-size:11px; padding-top:16px; border-top:1px solid #f3f4f6;'>" +
            "ร้านสุโขทัยแสงอุปกรณ์ | เริ่มที่นี่ no worry เรื่องบ้าน • โทร: 055-616437 | LINE: @exu1868n" +
          "</div>";

        // HTML เนื้อหาอีเมลสำหรับทางร้าน (มีรูปสลิป + ลิงก์ตาราง Sheet หลังบ้าน)
        const htmlBody = 
          "<div style='font-family:Prompt, Tahoma, sans-serif; max-width:650px; margin:0 auto; padding:20px; border:1px solid #e5e7eb; border-radius:12px; background:#ffffff;'>" +
            "<div style='background:#DC2626; color:#ffffff; padding:16px 20px; border-radius:8px; text-align:center; margin-bottom:20px;'>" +
              "<h2 style='margin:0 0 4px 0; font-size:22px; font-weight:bold;'>สุโขทัยแสงอุปกรณ์</h2>" +
              "<p style='margin:0; font-size:13px; opacity:0.95;'>มีคำสั่งซื้อสินค้าใหม่เข้ามาจากเว็บไซต์</p>" +
            "</div>" +
            
            "<div style='background:#f9fafb; padding:16px; border-radius:8px; margin-bottom:16px; border:1px solid #f3f4f6;'>" +
              "<p style='margin:4px 0; font-size:14px;'><strong>รหัสคำสั่งซื้อ:</strong> <span style='color:#DC2626; font-weight:bold;'>#" + postData.orderId + "</span></p>" +
              "<p style='margin:4px 0; font-size:13px;'><strong>วันที่สั่งซื้อ:</strong> " + orderDateStr + "</p>" +
              "<p style='margin:4px 0; font-size:14px;'><strong>ชื่อผู้สั่งซื้อ:</strong> " + (postData.customerName || "-") + "</p>" +
              "<p style='margin:4px 0; font-size:14px;'><strong>เบอร์โทรศัพท์:</strong> <a href='tel:" + postData.phone + "' style='color:#DC2626; font-weight:bold; font-size:15px;'>" + (postData.phone || "-") + "</a></p>" +
              "<p style='margin:4px 0; font-size:13px;'><strong>LINE ID:</strong> " + (postData.lineId || "-") + "</p>" +
              "<p style='margin:4px 0; font-size:13px;'><strong>อีเมลลูกค้า:</strong> " + (postData.customerEmail ? ("<a href='mailto:" + postData.customerEmail + "' style='color:#2563EB; font-weight:bold;'>" + postData.customerEmail + "</a>") : "-") + "</p>" +
              "<p style='margin:4px 0; font-size:13px;'><strong>รูปแบบการรับสินค้า:</strong> <span style='color:#15803d; font-weight:bold;'>" + deliveryMethodLabel + "</span></p>" +
              (!isPickup ? "<p style='margin:4px 0; font-size:13px;'><strong>ที่อยู่จัดส่ง:</strong> " + (postData.addressDetail || "-") + "</p>" : "") +
              "<p style='margin:4px 0; font-size:13px;'><strong>พิกัดหมุดจัดส่ง (GPS):</strong> <a href='" + mapsPinUrl + "' target='_blank' style='color:#2563EB; font-weight:bold;'>📍 " + (isPickup ? "พิกัดร้านสุโขทัยแสงอุปกรณ์" : "เปิดแผนที่นำทาง") + "</a></p>" +
              "<p style='margin:4px 0; font-size:13px;'><strong>วิธีชำระเงิน:</strong> " + (postData.paymentMethod || "-") + "</p>" +
              "<p style='margin:4px 0; font-size:13px;'><strong>หมายเหตุเพิ่มเติม:</strong> " + (postData.notes || "-") + "</p>" +
              deliveryNoticeHtml +
            "</div>" +
            
            slipBlockHtml +
            taxBlockHtml +
            itemsTableHtml +

            "<div style='background:#f0fdf4; border:1px solid #bbf7d0; border-radius:8px; padding:12px; margin-top:16px; margin-bottom:16px; font-size:12px; color:#166534;'>" +
              "📊 <strong>บันทึกลง Google Sheet:</strong> <a href='" + ss.getUrl() + "' target='_blank' style='color:#15803d; font-weight:bold; text-decoration:underline;'>คลิกเปิดดูตารางคำสั่งซื้อใน Sheet (ID: " + SPREADSHEET_ID + ") ↗</a>" +
              (sheetSaveStatus !== "success" ? "<br/><span style='color:#dc2626; font-weight:bold;'>⚠️ แจ้งเตือน: " + sheetSaveStatus + "</span>" : "") +
            "</div>" +

            storeFooterHtml +
          "</div>";

        const mailOptions = {
          to: TARGET_STORE_EMAIL,
          name: "ร้านสุโขทัยแสงอุปกรณ์ (SCG Home สุโขทัย)",
          subject: emailSubject,
          htmlBody: htmlBody
        };

        // ทางร้านสามารถกด Reply ตอบกลับหาอีเมลลูกค้าได้โดยตรง
        if (postData.customerEmail && postData.customerEmail.trim() !== "") {
          mailOptions.replyTo = postData.customerEmail.trim();
        }

        // แนบสลิปส่งให้ทางร้านสำหรับตรวจสอบยอดเงิน
        if (slipBlob) {
          mailOptions.attachments = [slipBlob];
          mailOptions.inlineImages = {
            slipImg: slipBlob
          };
        }

        MailApp.sendEmail(mailOptions);
        emailSendStatus = "sent";

        // ส่งอีเมลสรุปคำสั่งซื้อให้ลูกค้าโดยเฉพาะ (เห็นเฉพาะข้อมูลการสั่งซื้อ ไม่ส่งสลิป และไม่แสดงลิงก์ Sheet หลังบ้าน)
        if (postData.customerEmail && postData.customerEmail.trim() !== "") {
          try {
            const customerSubject = "📦 สรุปคำสั่งซื้อ #" + postData.orderId + " - ร้านสุโขทัยแสงอุปกรณ์";
            const customerHtml = 
              "<div style='font-family:Prompt, Tahoma, sans-serif; max-width:650px; margin:0 auto; padding:20px; border:1px solid #e5e7eb; border-radius:12px; background:#ffffff;'>" +
                "<div style='background:#DC2626; color:#ffffff; padding:16px 20px; border-radius:8px; text-align:center; margin-bottom:20px;'>" +
                  "<h2 style='margin:0 0 4px 0; font-size:22px; font-weight:bold;'>สุโขทัยแสงอุปกรณ์</h2>" +
                  "<p style='margin:0; font-size:13px; opacity:0.95;'>ใบสรุปรายการคำสั่งซื้อสินค้า</p>" +
                "</div>" +

                "<div style='background:#f0fdf4; border:1px solid #bbf7d0; border-radius:8px; padding:12px 16px; margin-bottom:16px; text-align:center;'>" +
                  "<h3 style='margin:0 0 4px 0; color:#166534; font-size:15px; font-weight:bold;'>ขอบพระคุณสำหรับคำสั่งซื้อค่ะ!</h3>" +
                  "<p style='margin:0; font-size:13px; color:#15803d;'>ทางร้านสุโขทัยแสงอุปกรณ์ได้รับคำสั่งซื้อของคุณเรียบร้อยแล้ว ด้านล่างคือรายละเอียดการสั่งซื้อค่ะ</p>" +
                "</div>" +

                "<div style='background:#f9fafb; padding:16px; border-radius:8px; margin-bottom:16px; border:1px solid #f3f4f6;'>" +
                  "<p style='margin:4px 0; font-size:14px;'><strong>รหัสคำสั่งซื้อ:</strong> <span style='color:#DC2626; font-weight:bold;'>#" + postData.orderId + "</span></p>" +
                  "<p style='margin:4px 0; font-size:13px;'><strong>วันที่สั่งซื้อ:</strong> " + orderDateStr + "</p>" +
                  "<p style='margin:4px 0; font-size:14px;'><strong>ชื่อผู้สั่งซื้อ:</strong> " + (postData.customerName || "-") + "</p>" +
                  "<p style='margin:4px 0; font-size:14px;'><strong>เบอร์โทรศัพท์:</strong> " + (postData.phone || "-") + "</p>" +
                  (postData.lineId ? "<p style='margin:4px 0; font-size:13px;'><strong>LINE ID:</strong> " + postData.lineId + "</p>" : "") +
                  "<p style='margin:4px 0; font-size:13px;'><strong>รูปแบบการรับสินค้า:</strong> <span style='color:#15803d; font-weight:bold;'>" + deliveryMethodLabel + "</span></p>" +
                  (!isPickup ? "<p style='margin:4px 0; font-size:13px;'><strong>ที่อยู่จัดส่ง:</strong> " + (postData.addressDetail || "-") + "</p>" : "") +
                  "<p style='margin:4px 0; font-size:13px;'><strong>วิธีชำระเงิน:</strong> " + (postData.paymentMethod || "-") + "</p>" +
                  (postData.notes ? "<p style='margin:4px 0; font-size:13px;'><strong>หมายเหตุเพิ่มเติม:</strong> " + postData.notes + "</p>" : "") +
                  deliveryNoticeHtml +
                "</div>" +

                taxBlockHtml +
                itemsTableHtml +
                storeFooterHtml +
              "</div>";

            const customerMailOptions = {
              to: postData.customerEmail.trim(),
              name: "ร้านสุโขทัยแสงอุปกรณ์",
              replyTo: TARGET_STORE_EMAIL,
              subject: customerSubject,
              htmlBody: customerHtml
            };

            // ไม่แนบ slipBlob ให้ลูกค้าตามคำขอ
            MailApp.sendEmail(customerMailOptions);
            Logger.log("✅ ส่งสรุปคำสั่งซื้อถึงลูกค้าสำเร็จ: " + postData.customerEmail);
          } catch (custMailErr) {
            Logger.log("⚠️ ส่งเมลตรงถึงลูกค้าเกิดข้อผิดพลาด: " + custMailErr.toString());
          }
        }
      } catch (mailErr) {
        Logger.log("Mail error: " + mailErr.toString());
        emailSendStatus = "error: " + mailErr.toString();
      }

      const response = {
        status: "success",
        orderId: postData.orderId,
        sheetId: SPREADSHEET_ID,
        slipUrl: slipUrl,
        emailStatus: emailSendStatus,
        message: "บันทึกออเดอร์ลง Sheet ID " + SPREADSHEET_ID + " เรียบร้อยแล้ว"
      };

      return ContentService.createTextOutput(JSON.stringify(response))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ==========================================
    // 2. กรณี: ถอดแบบประมาณการราคา (เดิม)
    // ==========================================
    const estSheetName = "ถอดแบบประมาณการ";
    let estSheet = ss.getSheetByName(estSheetName);

    if (!estSheet) {
      try {
        estSheet = ss.insertSheet(estSheetName);
      } catch (e) {
        estSheet = ss.getActiveSheet();
      }
      estSheet.appendRow([
        "ชื่อผู้ติดต่อ", 
        "เบอร์โทรศัพท์", 
        "ช่องทางการติดต่อออนไลน์", 
        "ที่อยู่อาคาร", 
        "แบบที่ต้องการแปลน หรือลิงก์ไดรฟ์",
        "วันที่ส่งข้อมูล"
      ]);
      estSheet.getRange(1, 1, 1, 6).setFontWeight("bold").setBackground("#1A1A1E").setFontColor("#FFFFFF");
      estSheet.setFrozenRows(1);
    }

    let fileUrl = "";
    if (postData.fileData && postData.fileName) {
      try {
        const fileBytes = Utilities.base64Decode(postData.fileData.split(",")[1] || postData.fileData);
        const blob = Utilities.newBlob(fileBytes, postData.fileType || "application/octet-stream", postData.fileName);

        let folder;
        if (DRIVE_FOLDER_ID && DRIVE_FOLDER_ID.trim() !== "") {
          folder = DriveApp.getFolderById(DRIVE_FOLDER_ID);
        } else {
          folder = DriveApp.getRootFolder();
        }

        const file = folder.createFile(blob);
        file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
        fileUrl = file.getUrl();
      } catch (fileError) {
        fileUrl = "เกิดข้อผิดพลาดในการเซฟไฟล์แนบ: " + fileError.toString();
      }
    }

    const finalFileOrLink = fileUrl || postData.driveLink || "ไม่มีไฟล์แนบ";

    estSheet.appendRow([
      postData.name || "",
      postData.phone || "",
      postData.onlineContact || "",
      postData.address || "",
      finalFileOrLink,
      new Date().toLocaleString("th-TH")
    ]);

    const response = { status: "success", fileUrl: fileUrl, message: "บันทึกข้อมูลถอดแบบเรียบร้อยแล้ว" };
    return ContentService.createTextOutput(JSON.stringify(response))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    const errorResponse = { status: "error", message: error.toString(), sheetId: SPREADSHEET_ID };
    return ContentService.createTextOutput(JSON.stringify(errorResponse))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doOptions(e) {
  const output = ContentService.createTextOutput();
  return output.setMimeType(ContentService.MimeType.TEXT);
}
